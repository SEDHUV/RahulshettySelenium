package miscellanous_topics;

public class chromeoptions {
    // Add the WebDriver proxy capability.
//    Proxy proxy = new Proxy();
//proxy.setHttpProxy("myhttpproxy:3337");
//options.setCapability("proxy", proxy);

    //block unwanted popups
//ChromeOptions options = new ChromeOptions();
//options.setExperimentalOption("excludeSwitches",
//     Arrays.asList("disable-popup-blocking"));

//// Add a ChromeDriver-specific capability.
//options.addExtensions(new File("/path/to/extension.crx"));
//    ChromeDriver driver = new ChromeDriver(options);

}
