package coreJava;

public class packageA {

    public void abc(){
        System.out.println("packageA");
    }
}
