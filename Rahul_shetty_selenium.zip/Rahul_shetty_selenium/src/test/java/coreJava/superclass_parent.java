package coreJava;

public class superclass_parent{

    public superclass_parent(){
        System.out.println("parent class constructor");
    }
    String name = "haema";
    public void getData(){
        System.out.println("parent method");
    }
}
