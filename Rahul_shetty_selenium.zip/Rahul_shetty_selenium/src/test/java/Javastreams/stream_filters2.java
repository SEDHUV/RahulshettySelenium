package Javastreams;

public class stream_filters2 {
    public static void main(String[] args) {

    }
}
