package Inheritance;

public class parent_class {
     static String name = "haema";

    public void mtdA(){
        System.out.println("methodA");
    }
    public void mtdB(){
        System.out.println("methodAB");
    }


}
