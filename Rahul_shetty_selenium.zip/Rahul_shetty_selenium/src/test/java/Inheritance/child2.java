package Inheritance;

public class child2 {


    public static void main(String[] args) {
        parent_class cc1 = new child_class();
      child_class cc2 = new child_class();
      System.out.println(cc2.name);
        System.out.println(cc1.name);
    }
}
