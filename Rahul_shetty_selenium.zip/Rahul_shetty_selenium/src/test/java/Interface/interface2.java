package Interface;

public interface interface2 {

    public void c();
}
