package Interface;

public interface interface1 {

    public void a ();
    public void b ();



}
