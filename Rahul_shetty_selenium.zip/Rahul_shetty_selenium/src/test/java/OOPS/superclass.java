package OOPS;

public class superclass {

    int b;

    public superclass(int g){
        this.b=g;
    }
    public int multiplyby2(){
        b=b *2;
        return b;
    }
}
