package OOPS;

public abstract class abstraction {

    public void guide(){
        System.out.println("guidelines");
    }

    public void measures(){
        System.out.println("measures");
    }
    public abstract void color();


}
