package OOPS;

public class increment
{
    public int increase(int b){
        b=b+1;
        return b;
    }
}
